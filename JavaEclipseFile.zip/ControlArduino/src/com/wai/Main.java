package com.wai;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;

import com.fazecast.jSerialComm.SerialPort;

public class Main extends JFrame implements ActionListener{
	private JComboBox<String>combo;
	private JButton button,button1;
	SerialPort port[],arduino;
	Main()
	{
		combo = new JComboBox<String>();
		button = new JButton("ON");
		button1 = new JButton("OFF");
		setLayout(null);
		combo.setBounds(100,50,200,25);
		button.setBounds(100,80,200,25);
		button1.setBounds(100,110,200,25);
		
		port = SerialPort.getCommPorts();
		for(int i=0;i<port.length;i++)
		{
			combo.addItem(port[i].getSystemPortName());
		}
		button.setEnabled(false);
		button1.setEnabled(false);
		
		add(combo);
		add(button);
		add(button1);
		setSize(400,400);
		setTitle("Arduino Control");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		combo.addActionListener(this);
		button.addActionListener(this);
		button1.addActionListener(this);
	}
	public static void main(String[]args)
	{
		Main main = new Main();
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == combo)
		{
			int i;
			String s;
			s = combo.getSelectedItem().toString();
			
			System.out.print(s);
			button.setEnabled(true);
			button1.setEnabled(true);
			
		}
		
		
	}

}
